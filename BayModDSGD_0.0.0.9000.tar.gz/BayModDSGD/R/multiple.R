#' @title Function for disease-specific gene detection for patients with multiple slices
#'
#' @param list_y a list of binary variables to indicate the spot status
#' @param matrix_x a matrix of covariates, with the coordinates placed in the final two columns of the matrix
#' @param label_list a list ranging from 1 to the total number of slices, indicating the slice to which each spot belongs. The length of this list must be equal to the number of samples.
#'
#' @return a fitted stan model
#' @export
#' @importFrom rstan stan_model
#' @importFrom rstan vb
#'
#' @examples \donttest{}
dsgd_multiple<-function(list_y,matrix_x,label_list){
  tmp_program<-"
data {
  int<lower=0> N;
  int<lower=0> P;
  int<lower=0> S;
  matrix[N,P+2] x;
  int y[N];
  vector[S] u_mu;
  int label[N];
}
parameters {
  vector[P] beta;
  real<lower=0,upper=8> eta;
  vector<lower=0>[P] beta_gamma;
  real<lower=0,upper=1> w;
  vector<lower=-1,upper=1>[S] U;
  real<lower=0,upper=1> sigma_square;
  real<lower=0,upper=1> rho;
}
model{

vector[N] mu;
matrix[N,N] prob_neigh;
matrix[S,S] covar_matrix;
rho ~ uniform(0,1);
sigma_square ~ inv_gamma(5,50);
for (i in 1:S){
  for (j in 1:S){
    if (i == j){
      covar_matrix[i,j]=sigma_square;
    }else{
      covar_matrix[i,j]=sigma_square*rho;
    }
  }
}

U ~ multi_normal(u_mu, covar_matrix);


for(i in 1:P){
  w ~ uniform(0,1);
  beta_gamma[i] ~ inv_gamma(5,50);
  target += log_sum_exp(log(1-w)+normal_lpdf(beta[i]|0,0.000001*beta_gamma[i]), log(w)+normal_lpdf(beta[i]|0,beta_gamma[i]));
}
for(i in 1:N) {
  for(j in 1:N){
    eta ~ uniform(0,8);
    if (label[i]==label[j] && j != i && sqrt(square(x[i,P+1]-x[j,P+1])+square(x[i,P+2]-x[j,P+2]))<=1){
      prob_neigh[i,j]=eta*y[j];
    }else{
      prob_neigh[i,j]=0;
    }}
  mu[i] = dot_product(x[i,1:P],beta)+sum(prob_neigh[i,])+U[label[i]];

}
y ~ bernoulli_logit(mu);
}"

stan_program <- tmp_program

stan_data <- list(
  N      = nrow(matrix_x),
  P      = ncol(matrix_x)-2,
  x      = matrix_x,
  y      = list_y,
  label  = label_list,
  S      = length(unique(label_list)),
  u_mu=rep(0,length(unique(label_list)))
)
autologistic_model<-stan_model(model_code = stan_program)
fit <- vb(autologistic_model,data = stan_data, algorithm = "fullrank",seed=128,tol_rel_obj=0.00001)
return(fit)
}
